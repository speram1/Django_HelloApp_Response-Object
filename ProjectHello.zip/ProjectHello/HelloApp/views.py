from django.http import JsonResponse 

# Create your views here.
def show(request):
    return JsonResponse({"Message": "Hello World!"})